package com.javacodegeeks.camel;

public class MyBean {
	public String appendCamel(String msg) {
		return msg + " Camel";
	}
}
