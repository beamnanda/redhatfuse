INSERT INTO books (item, description)
  VALUES
      ('Camel',    'Camel in Action'),
      ('ActiveMQ', 'ActiveMQ in Action');