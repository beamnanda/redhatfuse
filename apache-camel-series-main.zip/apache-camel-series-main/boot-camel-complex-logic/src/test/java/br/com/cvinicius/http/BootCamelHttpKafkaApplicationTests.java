package br.com.cvinicius.http;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootCamelHttpKafkaApplicationTests {

	@Test
	void contextLoads() {
	}

}
