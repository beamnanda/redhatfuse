CAMEL MARSHALL AND UNMARSHALL EXAMPLE(XmL to JSON )

===========================

To run this example:

1.mvn clean install

2.mvn compile exec:java -Dexec.mainClass=comavainuse.main.MainApp

