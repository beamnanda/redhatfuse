For information about .openshift directory, consult the documentation:

http://openshift.github.io/documentation/oo_user_guide.html#the-openshift-directory
