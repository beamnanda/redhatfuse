Configuring connector

- In order to run this connector you will need a Geonames account, which can be obtained at [http://www.geonames.org/login](http://www.geonames.org/login).
- Your flow's reqest must have a 'username' parameter set to your Geonames username.


Running connector

- Make a call on the http://localhost:8081/geonames URL.

