package com.camel.file.camelfile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CamelFileApplication {

	public static void main(String[] args) {
		SpringApplication.run(CamelFileApplication.class, args);
	}

}
