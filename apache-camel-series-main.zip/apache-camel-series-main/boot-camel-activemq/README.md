## Apache Camel com ActiveMQ

#### Criação do ActiveMQ

```sh
docker-compose up -d
```

Acessar a url: http://localhost:8161
- **usuário:** admin
- **senha:** admin

#### Executando a Aplicação

```sh
mvn spring-boot:run
```
