# spring-camel-rest-dsl
How to expose Rest API using Spring Boot with Apache Camel
