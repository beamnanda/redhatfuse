The API notebooks are all executable! Hit "enter" in any code cell to execute it (and all cells before it that have not executed yet), or scroll to the bottom of the notebook and click "Play notebook". For more information, see [http://apinotebook.com](http://apinotebook.com).

#Considerations

- In order to run these notebooks you will need register a Flight Stats developer account at [https://developer.flightstats.com/signup](https://developer.flightstats.com/signup)
- You should register a Flight Stats application at [https://developer.flightstats.com/admin/applications](https://developer.flightstats.com/admin/applications). At some point of the run, you will be prompted to enter the APPID and APPKEY of your own application.