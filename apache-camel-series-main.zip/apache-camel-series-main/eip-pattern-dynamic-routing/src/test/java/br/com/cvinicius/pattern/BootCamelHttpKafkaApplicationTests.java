package br.com.cvinicius.pattern;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootCamelHttpKafkaApplicationTests {

	@Test
	void contextLoads() {
	}

}
