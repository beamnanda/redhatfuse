 Recipient List Example
==================================

This example shows you how to use a Recipient List from Camel. 
To run this example, execute the following on the command line:

    mvn compile exec:java -Dexec.mainClass=camelinaction.OrderRouterWithRecipientListBean

