package com.camel.file.camelfile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CamelFileApplicationTests {

	@Test
	void contextLoads() {
	}

}
