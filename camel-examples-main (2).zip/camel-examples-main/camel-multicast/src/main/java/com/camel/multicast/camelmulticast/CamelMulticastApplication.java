package com.camel.multicast.camelmulticast;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CamelMulticastApplication {

	public static void main(String[] args) {
		SpringApplication.run(CamelMulticastApplication.class, args);
	}

}
