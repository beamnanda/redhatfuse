For information about markers, consult the documentation:

http://openshift.github.io/documentation/oo_user_guide.html#markers
