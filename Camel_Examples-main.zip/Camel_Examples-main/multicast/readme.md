Multicast Example
=============================

The first example shows you how to use a Multicast from Camel. 
To run this example, execute the following on the command line:

    mvn compile exec:java -Dexec.mainClass=camelinaction.OrderRouterWithMulticast

The last example shows you how to use a Multicast from Camel with parallel option. 
To run this example, execute the following on the command line:

    mvn compile exec:java -Dexec.mainClass=camelinaction.OrderRouterWithParallelMulticast
