Configuring connector

- No configuration required.


Running connector

- Make a call on the http://localhost:8081/fueleconomy URL.